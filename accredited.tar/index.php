<?php
/**
 * Home Page
 * Accredited Inspection Agency
 */

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/cache.php';

$page_title = 'Home';
$page_description = 'Accredited Inspection Agency - Professional Testing, Inspection and Certification Services. Delivering precise services that build trust and ensure compliance.';

// Get services for preview (cached for 5 min)
$services = get_cached_services($pdo);

include __DIR__ . '/includes/header.php';
?>

<!-- Hero Section -->
<section class="hero-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-7">
                <h1><?php echo SITE_TAGLINE; ?></h1>
                <p class="lead">Delivering precise testing and inspection services that build trust, ensure compliance,
                    and safeguard your business every step of the way.</p>
                <div class="d-flex flex-wrap gap-3">
                    <a href="<?php echo BASE_URL; ?>/services.php" class="btn btn-light btn-lg">Our Services</a>
                    <a href="<?php echo BASE_URL; ?>/contact.php" class="btn btn-outline-light btn-lg">Get a Quote</a>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- About Preview Section -->
<section class="section">
    <div class="container">
        <div class="row align-items-center g-5">
            <div class="col-lg-6">
                <span class="text-primary fw-semibold text-uppercase">About Us</span>
                <h2 class="section-title mt-2">Testing, Inspection and Certification Excellence</h2>
                <p class="text-muted mb-4">
                    Accredited Inspection Agency (AIA) was founded in 2025, bringing over 20 years of experience in
                    inspection and testing across industries such as steel, power, and cement. We provide accurate,
                    reliable, and transparent inspection and testing services that add true value to trade and industry.
                </p>
                <div class="row g-4 mb-4">
                    <div class="col-sm-6">
                        <div class="feature-box">
                            <div class="icon">
                                <i class="bi bi-award"></i>
                            </div>
                            <div>
                                <h6 class="mb-1">20+ Years</h6>
                                <small class="text-muted">Industry Experience</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="feature-box">
                            <div class="icon">
                                <i class="bi bi-shield-check"></i>
                            </div>
                            <div>
                                <h6 class="mb-1">Certified</h6>
                                <small class="text-muted">Quality Standards</small>
                            </div>
                        </div>
                    </div>
                </div>
                <a href="<?php echo BASE_URL; ?>/about.php" class="btn btn-primary">Learn More About Us</a>
            </div>
            <div class="col-lg-6">
                <div class="row g-3">
                    <div class="col-6">
                        <div class="stat-box bg-light rounded-3">
                            <div class="number">20+</div>
                            <div class="label">Years Experience</div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="stat-box bg-light rounded-3">
                            <div class="number">3</div>
                            <div class="label">Core Services</div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="stat-box bg-light rounded-3">
                            <div class="number">100%</div>
                            <div class="label">Quality Assured</div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="stat-box bg-light rounded-3">
                            <div class="number">24/7</div>
                            <div class="label">Support Available</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Services Section -->
<section class="section bg-light">
    <div class="container">
        <div class="text-center mb-5">
            <span class="text-primary fw-semibold text-uppercase">What We Offer</span>
            <h2 class="section-title mt-2">Our Services</h2>
            <p class="section-subtitle">We are dedicated to mitigating risks associated with the movement of
                commodities, ensuring reliability and accuracy at every stage.</p>
        </div>
        <div class="row g-4">
            <?php foreach ($services as $service): ?>
                <div class="col-md-4">
                    <div class="card service-card h-100">
                        <div class="card-body">
                            <div class="icon-box">
                                <i class="bi <?php echo htmlspecialchars($service['icon']); ?>"></i>
                            </div>
                            <h5><?php echo htmlspecialchars($service['title']); ?></h5>
                            <p class="text-muted mb-3">
                                <?php echo htmlspecialchars(substr($service['description'], 0, 100)); ?>...
                            </p>
                            <a href="<?php echo BASE_URL; ?>/service-detail.php?id=<?php echo $service['id']; ?>"
                                class="btn btn-outline-primary btn-sm">
                                Learn More <i class="bi bi-arrow-right ms-1"></i>
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>

        </div>
        <div class="text-center mt-5">
            <a href="<?php echo BASE_URL; ?>/services.php" class="btn btn-primary btn-lg">View All Services</a>
        </div>
    </div>
</section>

<!-- Why Choose Us Section -->
<section class="section">
    <div class="container">
        <div class="text-center mb-5">
            <span class="text-primary fw-semibold text-uppercase">Why Choose Us</span>
            <h2 class="section-title mt-2">Our Commitment to Excellence</h2>
        </div>
        <div class="row g-4">
            <div class="col-md-6 col-lg-3">
                <div class="text-center">
                    <div class="icon-box mx-auto mb-3">
                        <i class="bi bi-patch-check"></i>
                    </div>
                    <h5>Certified Experts</h5>
                    <p class="text-muted small">Well-qualified technical professionals including Mining Engineers,
                        Scientists, and Chemists.</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="text-center">
                    <div class="icon-box mx-auto mb-3">
                        <i class="bi bi-bullseye"></i>
                    </div>
                    <h5>Accuracy</h5>
                    <p class="text-muted small">Precise testing and inspection following Indian and International
                        standards.</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="text-center">
                    <div class="icon-box mx-auto mb-3">
                        <i class="bi bi-speedometer2"></i>
                    </div>
                    <h5>Fast Turnaround</h5>
                    <p class="text-muted small">Quick and efficient service delivery without compromising quality.</p>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <div class="text-center">
                    <div class="icon-box mx-auto mb-3">
                        <i class="bi bi-headset"></i>
                    </div>
                    <h5>24/7 Support</h5>
                    <p class="text-muted small">Round-the-clock customer support for all your inquiries.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="cta-section">
    <div class="container">
        <h3>Ready to Ensure Quality and Compliance?</h3>
        <p class="mb-4 opacity-75">Contact us today for professional inspection and testing services.</p>
        <a href="<?php echo BASE_URL; ?>/contact.php" class="btn btn-light btn-lg">Get Started</a>
    </div>
</section>

<?php include __DIR__ . '/includes/footer.php'; ?>